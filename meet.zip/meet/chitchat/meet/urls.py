from django.urls import path
from . import views

app_name = "meet"  # ✅ Define the app name

urlpatterns = [
    path("", views.lobby, name="lobby"),  # Homepage (lobby)
    path("room/", views.room, name="room"),
    path("gettoken/", views.gettoken, name="gettoken"),
    path('create_member/', views.createMember),
    path('get_member/', views.getMember),
    path('delete_member/', views.deleteMember),
]

