from django.shortcuts import render
from django.http import JsonResponse
import random
import time
from agora_token_builder import RtcTokenBuilder
from .models import RoomMember
import json
from django.views.decorators.csrf import csrf_exempt



# # Create your views here.
# def gettoken(request):
#      appId = 'a5d761476b924957b52ac14b6e741424'
#      appCertificate='cc51860c9b3a4928a54660afa41dc9b4'
#      channelName = request.GET.get('channelName')

    
#      uid = random.randint(1,230)
#      expirationTimeInSeconds = 30 * 24 * 60 * 60
#      currentTimestamp = time.time()
#      privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds
#      role = 1                                        
#      token = RtcTokenBuilder.buildTokenWithUid(appId, appCertificate, channelName, uid, role, privilegeExpiredTs)
#      return JsonResponse({'token': token, 'uid': uid},safe=False)
def gettoken(request):
    appId = 'a5d761476b924957b52ac14b6e741424'
    appCertificate = 'cc51860c9b3a4928a54660afa41dc9b4'
    channelName = request.GET.get('channelName')
    
    if not channelName:  # Check if channelName is provided in the request
        return JsonResponse({'error': 'channelName is required'}, status=400)
    
    uid = random.randint(1, 230)
    
    # Set the expiration time to 30 days (2592000 seconds)
    expirationTimeInSeconds = 30 * 24 * 60 * 60  # 30 days in seconds
    
    currentTimestamp = time.time()
    privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds
    
    role = 1  # Assuming 1 is the "host" role
    
    try:
        # Generate the token
        token = RtcTokenBuilder.buildTokenWithUid(appId, appCertificate, channelName, uid, role, privilegeExpiredTs)
        
        # Return the token and UID in a JSON response
        return JsonResponse({'token': token, 'uid': uid}, safe=False)
    except Exception as e:
        # If something goes wrong, return the error message
        return JsonResponse({'error': str(e)}, status=500)
def lobby(request):
     return render(request, 'meet/lobby.html')
def room(request):
    room_name = request.GET.get("room") 
    username = request.GET.get("username", "Guest")  
    
    if not room_name:
        return render(request, "meet/lobby.html", {"error": "Room name is required"})
    
    return render(request, "meet/room.html", {
        "room_name": room_name, 
        "username": username
    })
# @csrf_exempt
# def createMember(request):
#     data = json.loads(request.body)
#     if 'name' not in data or not data['name']:
#         return JsonResponse({'error': 'Name is required'}, status=400)
    
#     member, created = RoomMember.objects.get_or_create(
#         name=data['name'],
#         uid=data['uid'],
#         room_name=data['room_name']
#     )

#     return JsonResponse({'name':data['name']}, safe=False)

@csrf_exempt
def createMember(request):
    if request.method != "POST":
        return JsonResponse({'error': 'Invalid request method'}, status=405)

    try:
        if not request.body:
            return JsonResponse({'error': 'Empty request body'}, status=400)

        data = json.loads(request.body)

        if 'name' not in data or not data['name']:
            return JsonResponse({'error': 'Name is required'}, status=400)

        if 'uid' not in data or not data['uid']:
            return JsonResponse({'error': 'UID is required'}, status=400)

        if 'room_name' not in data or not data['room_name']:
            return JsonResponse({'error': 'Room name is required'}, status=400)

        member, created = RoomMember.objects.get_or_create(
            name=data['name'],
            uid=data['uid'],
            room_name=data['room_name']
        )

        return JsonResponse({'name': data['name']}, safe=False)

    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

def getMember(request):
    uid = request.GET.get('uid')
    room_name = request.GET.get('room_name')

    member = RoomMember.objects.get(
        uid=uid,
        room_name=room_name,
    )
    name = member.name
    return JsonResponse({'name':member.name}, safe=False)

@csrf_exempt
def deleteMember(request):
    if request.method != "POST":
        return JsonResponse({'error': 'Invalid request method'}, status=405)

    try:
        data = json.loads(request.body)

        member = RoomMember.objects.get(
            name=data['name'],
            uid=data['uid'],
            room_name=data['room_name']
        )
        member.delete()

        return JsonResponse({'message': 'Member deleted successfully'}, status=200)

    except RoomMember.DoesNotExist:
        return JsonResponse({'error': 'Member not found'}, status=404)

    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

